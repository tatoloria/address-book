<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<link rel="stylesheet" href="styles/style.css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
	
	<link rel="stylesheet" href="jquery-ui-1.12.1/jquery-ui.min.css">
	<script src="jquery-ui-1.12.1/external/jquery/jquery.js"></script>
	<script src="jquery-ui-1.12.1/jquery-ui.min.js"></script>
	
	<script type="text/javascript" src="scripts/contacts.js"></script>
	<script type="text/javascript" src="scripts/cities.js"></script>
	
	<script type="text/javascript">
	
		$(document).ready(function () {
		
			GetContacts();
			GetCities();
		
		   $('#dlgNewContact').dialog({
                autoOpen: false,
                modal: true,
                width: 400,
                height: 450,
                draggable: true,
                title: "New Contact",
                open: function (type, data) {
                    $(this).parent().appendTo("form");
                }
            });
			
			$('#dlgEditContact').dialog({
                autoOpen: false,
                modal: true,
                width: 400,
                height: 450,
                draggable: true,
                title: "Edit Contact",
                open: function (type, data) {
                    $(this).parent().appendTo("form");
                }
            });
			
		});
		
		function showDialog(id) {
			$('#' + id).dialog("open");
		}

		function closeDialog(id) {
			$('#' + id).dialog("close");
		}
		
	</script>
  
</head>

<body>
	
	<div class="header">
		<div class="logo"><img src="images/address-book.png" alt="address book image" height="100" width="100"></div>
		<div class="headerTitle">
			<h1>BWE ADDRESS BOOK</h1>
		</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="body">
		
		<div id="content">
			<div class="contentHeader">
				<div class="contentTitle">
					<h1>CONTACTS</h2>
				</div>
				<div class="contentOptions">
					<input type="submit" name="btnNewContact" id="btnNewContact" value="New Contact" class="button" onclick="CleanNewContactDialog(); showDialog('dlgNewContact');">
				</div>
			</div>
			<div id="contentDetails">
			</div>
		</div>
		
		<div id="dlgNewContact" title="New Contact">
			<table>
				<tr>
					<td width=100>Name:</td>
					<td align="center"><input type="text" id="name" name="name" placeholder="Name"></td>
				</tr>
				<tr>
					<td>First Name:</td>
					<td align="center"><input type="text" id="first_name" name="first_name" placeholder="First Name"></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td align="center"><input type="email" id="email" name="email" placeholder="Email"></td>
				</tr>
				<tr>
					<td>Street:</td>
					<td align="center"><input type="text" id="street" name="street" placeholder="Street"></td>
				</tr>
				<tr>
					<td>Zip Code:</td>
					<td align="center"><input type="text" id="zip_code" name="zip_code" placeholder="Zip Code"></td>
				</tr>
				<tr>
					<td>City:</td>
					<td align="center"><select id="city" name="city"></td>
				</tr>
				<tr>
					<td align="center" colspan=2><button type="submit" class="button" onclick="InsertContact();">OK</button></td>
				</tr>
			</table>
		</div>
		
		<div id="dlgEditContact" title="Edit Contact">
			<input type="hidden" id="edit_id" name="edit_id">
			<table>
				<tr>
					<td width=100>Name:</td>
					<td align="center"><input type="text" id="edit_name" name="edit_name" placeholder="Name"></td>
				</tr>
				<tr>
					<td>First Name:</td>
					<td align="center"><input type="text" id="edit_first_name" name="edit_first_name" placeholder="First Name"></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td align="center"><input type="email" id="edit_email" name="edit_email" placeholder="Email"></td>
				</tr>
				<tr>
					<td>Street:</td>
					<td align="center"><input type="text" id="edit_street" name="edit_street" placeholder="Street"></td>
				</tr>
				<tr>
					<td>Zip Code:</td>
					<td align="center"><input type="text" id="edit_zip_code" name="edit_zip_code" placeholder="Zip Code"></td>
				</tr>
				<tr>
					<td>City:</td>
					<td align="center"><select id="edit_city" name="edit_city"></td>
				</tr>
				<tr>
					<td align="center" colspan=2><button type="submit" class="button" onclick="UpdateContact();">Update</button>
					</td>
				</tr>
			</table>		
		</div>
		
	</div>

</body>
		
</html>