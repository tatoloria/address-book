<?php
	
include("../db.php");

$db = new db();

$method = "";
$method = $_GET['m'];

switch ($method) {
	case "GetCities":
		$cities = $db->GetCities();
		
		// default option
		echo "<option value=-1 selected>Select a city</option>";
		
		while($row = $cities->fetch_object()) {
			echo "<option value=" . $row->city_id . ">" . utf8_encode($row->city_name) . "</option>";
		}
			
        break;
	default:
		break;
}

?>