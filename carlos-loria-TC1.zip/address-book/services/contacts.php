<?php
	
include("../db.php");

$db = new db();

$method = "";
$method = $_GET['m'];

switch ($method) {
	case "GetContacts":
		$contacts = $db->GetContacts();
		ShowContacts($contacts);
        break;
	case "InsertContact":
		$contact = new stdClass();
		$contact->name = $_POST['name'];
		$contact->first_name = $_POST['first_name'];
		$contact->email = $_POST['email'];
		$contact->street = $_POST['street'];
		$contact->zip_code = $_POST['zip_code'];
		$contact->city_id = $_POST['city'];
        $db->InsertContact($contact);
        $contacts = $db->GetContacts();
		ShowContacts($contacts);
        break;
	case "GetContact":
		$id = $_GET['id'];
        $contact = $db->GetContact($id);
		echo json_encode($contact);
        break;
	case "UpdateContact":
		$contact = new stdClass();
		$contact->contact_id = $_POST['contact_id'];
		$contact->name = $_POST['name'];
		$contact->first_name = $_POST['first_name'];
		$contact->email = $_POST['email'];
		$contact->street = $_POST['street'];
		$contact->zip_code = $_POST['zip_code'];
		$contact->city_id = $_POST['city'];
        $db->UpdateContact($contact);
        $contacts = $db->GetContacts();
		ShowContacts($contacts);
        break;
	default:
		break;
}

function ShowContacts($contacts) {
	echo "<table>
	<thead>
	<tr>
		<th>Name</th>
		<th>First Name</th>
		<th>Email</th>
		<th>Street</th>
		<th>Zip Code</th>
		<th>City</th>
		<th align='center'>Edit</th>
	</thead>
	</tr>";
	
	while($row = $contacts->fetch_object()) {
		echo "<tr>";
		echo "<td>" . $row->name . "</td>";
		echo "<td>" . $row->first_name . "</td>";
		echo "<td>" . $row->email . "</td>";
		echo "<td>" . $row->street . "</td>";
		echo "<td>" . $row->zip_code . "</td>";
		echo "<td>" . utf8_encode($row->city_name) . "</td>";
		echo "<td><div class='editContact' onclick='GetContact(" . $row->contact_id . ")'></td>";
		echo "</tr>";
	}
	
	echo "</table>";
}

?>