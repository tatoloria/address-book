/* Script for contacts functionality */

function GetContacts()
{
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			$("#contentDetails").html(this.responseText);
		}
	};
	xmlhttp.open("GET","services/contacts.php?m=GetContacts",true);
	xmlhttp.send();
}

function CleanNewContactDialog()
{
	// Clean form
	$("#name").val("");
	$("#first_name").val("");
	$("#email").val("");
	$("#street").val("");
	$("#zip_code").val("");
	$("#city").val("-1");
}

function InsertContact()
{
	var name = $("#name").val();
	var first_name = $("#first_name").val();
	var email = $("#email").val();
	var street = $("#street").val();
	var zip_code = $("#zip_code").val();
	var city = $("#city").val();
	
	var formData = new FormData();

	formData.append("name", name);
	formData.append("first_name", first_name);
	formData.append("email", email);
	formData.append("street", street);
	formData.append("zip_code", zip_code);
	formData.append("city", city);
	
	
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			$("#contentDetails").html(this.responseText);
			closeDialog("dlgNewContact");
		}
	};
	xmlhttp.open("POST","services/contacts.php?m=InsertContact",true);
	xmlhttp.send(formData);
}

function GetContact(id)
{
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var contact = JSON.parse(this.responseText);
			$("#edit_id").val(contact.contact_id);
			$("#edit_name").val(contact.name);
			$("#edit_first_name").val(contact.first_name);
			$("#edit_email").val(contact.email);
			$("#edit_street").val(contact.street);
			$("#edit_zip_code").val(contact.zip_code);
			$("#edit_city").val(contact.city_id);
			showDialog("dlgEditContact");
		}
	};
	xmlhttp.open("GET","services/contacts.php?m=GetContact&id="+id,true);
	xmlhttp.send();
}

function UpdateContact()
{
	var contact_id = $("#edit_id").val();
	var name = $("#edit_name").val();
	var first_name = $("#edit_first_name").val();
	var email = $("#edit_email").val();
	var street = $("#edit_street").val();
	var zip_code = $("#edit_zip_code").val();
	var city = $("#edit_city").val();
	
	var formData = new FormData();

	formData.append("contact_id", contact_id);
	formData.append("name", name);
	formData.append("first_name", first_name);
	formData.append("email", email);
	formData.append("street", street);
	formData.append("zip_code", zip_code);
	formData.append("city", city);
	
	
	if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {
		// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			$("#contentDetails").html(this.responseText);
			closeDialog("dlgEditContact");
		}
	};
	xmlhttp.open("POST","services/contacts.php?m=UpdateContact",true);
	xmlhttp.send(formData);
}