<?

class db {

	protected $servername = "SERVERIP";
	protected $username = "USER";
	protected $password = "PASSWORD";
	protected $dbname = "BWE_address_book";
	
	public $connection = null;

	// Create connection
	function Connect()
	{
		$this->connection = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname);
	}

	// Close connection
	function Close()
	{
		mysqli_close($this->connection);
	}
	
	// Get Cities
	function GetCities()
	{
		$this->Connect();
		
		$sql = "select city_id, city_name
				from cities
				order by city_name";
		
		$result = $this->connection->query($sql);

		$this->Close();
		
		return $result;
	}
	
	// Get Contacts
	function GetContacts()
	{
		$this->Connect();
		
		$sql = "select contact_id, name, first_name, email, street, zip_code, city_name
				from contacts co left join cities ci on co.city_id = ci.city_id
				order by name";
		
		$result = $this->connection->query($sql);

		$this->Close();
		
		return $result;
	}
	
	// Get Contact by id
	function GetContact($id)
	{
		$this->Connect();
		
		$sql = "select contact_id, name, first_name, email, street, zip_code, city_id
				from contacts
				where contact_id = $id";
				
		$result = $this->connection->query($sql);
		$this->Close();
		
		return $result->fetch_object();
	}

	// Insert Contact
	function InsertContact($contact)
	{
		$this->Connect();

		//sanitize input data
		$name = $this->connection->escape_string($contact->name);
		$first_name = $this->connection->escape_string($contact->first_name);
		$email = $this->connection->escape_string($contact->email);
		$street = $this->connection->escape_string($contact->street);
		$zip_code = $this->connection->escape_string($contact->zip_code);
		$city_id = $this->connection->escape_string($contact->city_id);
		
		$sql =	sprintf("insert into contacts(name, first_name, email, street, zip_code, city_id)
				values('%s', '%s', '%s', '%s', '%s', %s)", $name, $first_name, $email, $street, $zip_code, $city_id);
		
		$result = $this->connection->query($sql);

		$this->Close();
	}
	
	// Update Contact
	function UpdateContact($contact)
	{
		$this->Connect();

		//sanitize input data
		$contact_id = $this->connection->escape_string($contact->contact_id);
		$name = $this->connection->escape_string($contact->name);
		$first_name = $this->connection->escape_string($contact->first_name);
		$email = $this->connection->escape_string($contact->email);
		$street = $this->connection->escape_string($contact->street);
		$zip_code = $this->connection->escape_string($contact->zip_code);
		$city_id = $this->connection->escape_string($contact->city_id);
		
		$sql =	sprintf("update contacts
				set name='%s', first_name='%s', email='%s', street='%s', zip_code='%s', city_id=%s
				where contact_id=%s", $name, $first_name, $email, $street, $zip_code, $city_id, $contact_id);
				
		$result = $this->connection->query($sql);

		$this->Close();
	}

}

?>